function turnOff(element) {
    element.innerText = "Login";
}
function hide(element) {
    element.remove();
}
